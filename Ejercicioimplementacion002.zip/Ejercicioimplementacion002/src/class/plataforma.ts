import { Canales } from "./canales";

export class Plataforma {
    private nombre:string;
    private logo:string;
    private descripcion:string;
    private empresa:string;
    private listadoPlataformas:Plataforma[]=[];
    private canales: Canales[];

    constructor(nombre?:string, logo?:string, description?:string,empresa?:string, listadoPlataformas?:Plataforma[]) {
        this.nombre=nombre||"";
        this.logo=logo||"";
        this.descripcion=description||"";
        this.empresa=empresa||"";
        this.listadoPlataformas=listadoPlataformas||[];
        this.canales=[];
    }

    agregarcanal(canal:Canales):void{
        this.canales.push(canal);
    }

    getDetallePlataforma(){
        return{
            nombre:this.nombre,
            logo:this.logo,
            descripcion:this.descripcion,
            empresa:this.empresa,
            canales:this.canales,
        };
    }
    mostrarDetalle(){
        console.log(this.getDetallePlataforma());
    }
    agregarPlataforma(plataforma: Plataforma){
        this.listadoPlataformas.push(plataforma);
    }
    obtenerListadoPlataforma(){
        return this.listadoPlataformas;
    }
    mostrarListadoPlataforma(){
        console.log(this.obtenerListadoPlataforma())
    }

    getDetalleListaPlataforma(buscar:string){
        return this.listadoPlataformas.filter(x=> x.nombre==buscar)[0];
    }


}



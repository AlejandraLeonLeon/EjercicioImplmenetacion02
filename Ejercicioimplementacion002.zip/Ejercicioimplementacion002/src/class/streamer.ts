import { Canales } from "./canales";
import { Stream } from "./stream";


export class Streamer {
    private nickname:string;
    private descripcion: string;
    private redesList: string[]=[];
    private canales:Canales[];
    private stream:Stream[];
    private listadoStreamers:Streamer[]=[];

    constructor(nickname?:string, descripcion?:string, redesList?: string[]){
        this.nickname=nickname||"";
        this.descripcion=descripcion||"";
        this.redesList=redesList||[];
        this.canales=[];
        this.stream=[];
        this.listadoStreamers=[];
    }

    agregarcanal(canal:Canales):void{
        this.canales.push(canal);
    }
    agregarStream(stream:Stream):void{
        this.stream.push(stream);
    }
    getDetalleStreamer(){
        return{
            nickname:this.nickname,
            descripcion:this.descripcion,
            redesList:this.redesList,
            canales:this.canales,
            stream:this.stream,
        };
    }
    mostrarDetalle(){
        console.log(this.getDetalleStreamer());
    }
    agregarStreamer(streamer: Streamer){
        this.listadoStreamers.push(streamer);
    }
    obtenerListadoStreamer(){
        return this.listadoStreamers;
    }
    mostrarListadoStreamer(){
        console.log(this.obtenerListadoStreamer())
    }

    getDetalleListaStreamer(buscar:string){
        return this.listadoStreamers.filter(x=> x.nickname==buscar)[0];
    }
}
export class Canales  {
    private nombre:string;
    private banner:string;
    private nameStreamer:string;
    private descripcion:string;
    private listaCanales:Canales[]=[];


    constructor(nombre?:string, banner?:string, nameStreamer?: string, descripcion?:string){
        this.nombre=nombre||"";
        this.banner=banner||"";
        this.nameStreamer=nameStreamer||"";
        this.descripcion=descripcion||"";
        this.listaCanales=[];
    }
    getDetalleCanal(){
        return{
            nombre:this.nombre,
            banner:this.banner,
            nameStreamer:this.nameStreamer,
            descripcion:this.descripcion,
        };
    }
    mostrarDetalle(){
        console.log(this.getDetalleCanal());
    }
    agregarCanales(canal: Canales){
        this.listaCanales.push(canal);
    }
    obtenerListadoCanales(){
        return this.listaCanales;
    }
    mostrarListadoCanales(){
        console.log(this.obtenerListadoCanales());
    }
    getDetalleListaCanales(buscar:string){
        return this.listaCanales.filter(x=> x.nombre==buscar)[0];
    }
}

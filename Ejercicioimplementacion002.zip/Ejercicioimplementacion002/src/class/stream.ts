import { Canales } from "./canales";
export class Stream {
    private categoria:string;
    private espacio:string;
    private tema:string;
    private listadoStreams:Stream[]=[];


    constructor(categoria?:string, espacio?:string, tema?:string){
        this.categoria=categoria||"";
        this.espacio=espacio||"";
        this.tema=tema||"";
        this.listadoStreams=[];

    }

    getDetalleStream(){
        return{
            categoria:this.categoria,
            espacio:this.espacio,
            tema:this.tema,
        };
    }
    mostrarDetalle(){
        console.log(this.getDetalleStream());
    }
    agregarStream(stream: Stream){
        this.listadoStreams.push(stream);
    }
    obtenerListadoStream(){
        return this.listadoStreams;
    }
    mostrarListadoStream(){
        console.log(this.obtenerListadoStream())
    }


}
import { Plataforma } from "./class/plataforma.js";
import { Stream } from "./class/stream.js";
import { Streamer } from "./class/streamer.js";
import { Canales } from "./class/canales.js";



let plataforma= new Plataforma();
let plataforma1 = new Plataforma("Twitch","logoTwitch.png","Twitch es una plataforma estadounidense perteneciente a la empresa Amazon, Inc., que permite realizar transmisiones en vivo. Esta plataforma tiene como función principal la retransmisión de videojuegos en directo, un campo en el que tiene como competidor a YouTube", "Amazon");
let plataforma2 = new Plataforma("YouTube Gaming", "logoYouTubeGaming.png","es un sitio web de origen estadounidense dedicado a compartir videos. Presenta una variedad de clips de películas, programas de televisión y vídeos musicales, así como contenidos amateur como videoblogs y YouTube Gaming. Las personas que crean contenido para esta plataforma generalmente son conocidas como youtubers.","Google Inc");

let canal=new Canales();
let canal1= new Canales("Shakira","Shakira.png","Shakira Mebarak","42.7 millones de seguidores");
let canal2 = new Canales("Ibai","Ibai.png","Ibai Llanos Garetea","13.1 millones seguidores");

let redes:string[]=["Facebook", "Instagram", "YouTube", "TikTok", "Twitter"]

let streamer=new Streamer();
let streamer1=new Streamer("Shakira","Cantante",redes);
let streamer2=new Streamer("Ibai", "Creador contenido", redes);

let stream=new Stream();
let stream1=new Stream("Canciones", "estudio","Música");
let stream2=new Stream("Contenido","Estudio","Fútbol")

plataforma.agregarPlataforma(plataforma1);
plataforma.agregarPlataforma(plataforma2);
plataforma1.agregarcanal(canal2);
plataforma2.agregarcanal(canal1);
console.log(plataforma.mostrarListadoPlataforma());
plataforma1.mostrarDetalle();

console.log(plataforma.getDetalleListaPlataforma("Twitch"));

canal.agregarCanales(canal1);
canal.agregarCanales(canal2);
console.log(canal.mostrarListadoCanales());
canal1.mostrarDetalle();

streamer.agregarStreamer(streamer1);
streamer.agregarStreamer(streamer2);
streamer1.agregarStream(stream1);
streamer2.agregarStream(stream2);
console.log(streamer.mostrarListadoStreamer());
streamer1.agregarcanal(canal1);
streamer1.mostrarDetalle();


stream.agregarStream(stream1);
stream.agregarStream(stream2);
console.log(stream.mostrarListadoStream());


